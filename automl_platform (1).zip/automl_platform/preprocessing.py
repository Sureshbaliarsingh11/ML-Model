"""
preprocessing.py
Handles data quality checks, missing value treatment, encoding, scaling,
and class imbalance correction for the AutoML platform.
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer


def detect_problem_type(df: pd.DataFrame, target_col: str) -> str:
    """
    Auto-detects whether the target column implies a classification
    or regression problem.

    Heuristic:
    - Non-numeric dtype -> classification
    - Numeric but few unique values relative to row count -> classification
    - Otherwise -> regression
    """
    target = df[target_col]
    n_rows = len(df)
    n_unique = target.nunique(dropna=True)

    if not pd.api.types.is_numeric_dtype(target):
        return "classification"

    # Numeric column with low cardinality is likely a coded category (e.g., 0/1, 1-5 rating)
    if n_unique <= 20 or (n_unique / n_rows) < 0.05:
        return "classification"

    return "regression"


def get_missing_value_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Returns a summary table of missing values per column."""
    missing = df.isnull().sum()
    pct = (missing / len(df) * 100).round(2)
    summary = pd.DataFrame({
        "column": df.columns,
        "missing_count": missing.values,
        "missing_pct": pct.values,
        "dtype": df.dtypes.astype(str).values
    })
    return summary[summary["missing_count"] > 0].sort_values("missing_pct", ascending=False)


def handle_missing_values(df: pd.DataFrame, strategy: str, columns_to_drop: list = None) -> pd.DataFrame:
    """
    Applies the user-chosen missing value strategy.

    strategy options:
        - "drop_rows": drop any row with a missing value
        - "impute": mean/median for numeric, mode for categorical
        - "drop_columns": drop the specified columns_to_drop entirely
    """
    df = df.copy()

    if strategy == "drop_columns" and columns_to_drop:
        df = df.drop(columns=columns_to_drop)
        # Any remaining missing values get imputed as a safety net
        strategy = "impute"

    if strategy == "drop_rows":
        df = df.dropna()

    elif strategy == "impute":
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        categorical_cols = df.select_dtypes(exclude=[np.number]).columns

        for col in numeric_cols:
            if df[col].isnull().any():
                df[col] = df[col].fillna(df[col].median())

        for col in categorical_cols:
            if df[col].isnull().any():
                mode_val = df[col].mode()
                fill_val = mode_val[0] if not mode_val.empty else "Unknown"
                df[col] = df[col].fillna(fill_val)

    return df


def detect_outliers_iqr(df: pd.DataFrame, numeric_cols: list) -> pd.DataFrame:
    """Returns a summary of outlier counts per numeric column using IQR method."""
    rows = []
    for col in numeric_cols:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        n_outliers = ((df[col] < lower) | (df[col] > upper)).sum()
        rows.append({"column": col, "outlier_count": n_outliers, "lower_bound": lower, "upper_bound": upper})
    return pd.DataFrame(rows)


def cap_outliers(df: pd.DataFrame, numeric_cols: list) -> pd.DataFrame:
    """Caps outliers to the IQR bounds (winsorization) instead of dropping rows."""
    df = df.copy()
    for col in numeric_cols:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        df[col] = df[col].clip(lower=lower, upper=upper)
    return df


def build_preprocessing_pipeline(numeric_cols: list, categorical_cols: list, scale_numeric: bool = True):
    """
    Builds a sklearn ColumnTransformer that one-hot encodes categoricals
    and optionally scales numeric features. Used inside model pipelines
    so the same transform is applied consistently at train and predict time.
    """
    numeric_steps = [("imputer", SimpleImputer(strategy="median"))]
    if scale_numeric:
        numeric_steps.append(("scaler", StandardScaler()))
    numeric_transformer = Pipeline(steps=numeric_steps)

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_cols),
            ("cat", categorical_transformer, categorical_cols)
        ],
        remainder="drop"
    )

    return preprocessor


def encode_target(y: pd.Series):
    """
    Label encodes a classification target if it's non-numeric.
    Returns the encoded target and the fitted encoder (or None for regression/numeric targets).
    """
    if not pd.api.types.is_numeric_dtype(y):
        le = LabelEncoder()
        y_encoded = le.fit_transform(y)
        return y_encoded, le
    return y.values, None


def check_class_imbalance(y: pd.Series, threshold: float = 0.3) -> dict:
    """
    Checks if a classification target is imbalanced.
    Returns whether imbalance is detected and the class distribution.
    """
    counts = y.value_counts(normalize=True)
    is_imbalanced = (counts.min() < threshold)
    return {
        "is_imbalanced": bool(is_imbalanced),
        "distribution": counts.to_dict()
    }


def apply_smote(X, y):
    """Applies SMOTE oversampling to balance classes. X must already be numeric (post-encoding)."""
    from imblearn.over_sampling import SMOTE
    smote = SMOTE(random_state=42)
    X_res, y_res = smote.fit_resample(X, y)
    return X_res, y_res
