"""
utils.py
Helper functions for business-friendly explanations, model persistence,
and applying a trained pipeline to new uploaded data for predictions.
"""

import joblib
import pandas as pd
import os


METRIC_EXPLANATIONS = {
    "Accuracy": "Out of 100 predictions, how many were correct.",
    "Precision": "When the model predicts 'yes', how often it's actually right.",
    "Recall": "Out of all the real 'yes' cases, how many the model caught.",
    "F1 Score": "A balance between Precision and Recall (higher is better).",
    "ROC AUC": "How well the model separates the classes overall (1.0 = perfect, 0.5 = random guessing).",
    "RMSE": "Average prediction error, in the same units as your target (lower is better).",
    "MAE": "Average absolute difference between predicted and actual values (lower is better).",
    "MAPE (%)": "Average prediction error as a percentage of the actual value (lower is better).",
    "R2": "Percentage of the variation in your target that the model explains (closer to 100% is better).",
}


def get_metric_explanation(metric_name: str) -> str:
    return METRIC_EXPLANATIONS.get(metric_name, "")


def plain_language_summary(best_model_row: dict, problem_type: str) -> str:
    """Generates a short, non-technical summary of the best model's performance."""
    name = best_model_row.get("Model", "The selected model")

    if problem_type == "classification":
        acc = best_model_row.get("Accuracy")
        f1 = best_model_row.get("F1 Score")
        if acc is not None:
            return (
                f"**{name}** performed best. It correctly predicts the outcome "
                f"about **{acc * 100:.1f}%** of the time on data it hadn't seen before, "
                f"with a balanced F1 score of **{f1:.2f}**."
            )
    else:
        r2 = best_model_row.get("R2")
        mape = best_model_row.get("MAPE (%)")
        if r2 is not None:
            extra = f" Predictions are typically within **{mape:.1f}%** of the actual value." if mape else ""
            return (
                f"**{name}** performed best. It explains about **{r2 * 100:.1f}%** "
                f"of the variation in your target value.{extra}"
            )

    return f"**{name}** performed best based on the evaluation metrics above."


def save_model(pipeline, model_name: str, save_dir: str = "saved_models") -> str:
    """Saves a fitted pipeline to disk and returns the file path."""
    os.makedirs(save_dir, exist_ok=True)
    safe_name = model_name.replace(" ", "_").lower()
    path = os.path.join(save_dir, f"{safe_name}_model.joblib")
    joblib.dump(pipeline, path)
    return path


def load_model(path: str):
    """Loads a previously saved pipeline."""
    return joblib.load(path)


def predict_on_new_data(pipeline, new_df: pd.DataFrame, label_encoder=None) -> pd.DataFrame:
    """
    Runs a trained pipeline on new uploaded data and returns the original
    data with a 'Prediction' column appended. Decodes labels back to their
    original categories if a label encoder was used during training.
    """
    predictions = pipeline.predict(new_df)

    if label_encoder is not None:
        predictions = label_encoder.inverse_transform(predictions)

    result = new_df.copy()
    result["Prediction"] = predictions
    return result
