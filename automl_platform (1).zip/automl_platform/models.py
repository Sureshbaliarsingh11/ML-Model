"""
models.py
Defines the algorithm registry (classification + regression), trains every
candidate model inside a consistent pipeline, and produces a leaderboard
of evaluation metrics.
"""

import time
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVC
from xgboost import XGBClassifier, XGBRegressor
from lightgbm import LGBMClassifier, LGBMRegressor

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error
)

from preprocessing import build_preprocessing_pipeline


# ---------------------------------------------------------------------------
# Algorithm registry
# Each entry: rank, display name, rating (stars), short rationale, and the
# sklearn-compatible estimator with sensible default hyperparameters for
# small tabular datasets (<10k rows).
# ---------------------------------------------------------------------------

CLASSIFICATION_MODELS = {
    "Random Forest": {
        "rank": 1,
        "rating": "★★★★★",
        "why": "Robust default, handles mixed data well, minimal tuning needed.",
        "estimator": RandomForestClassifier(
            n_estimators=300, max_depth=12, min_samples_leaf=2,
            random_state=42, n_jobs=-1
        )
    },
    "XGBoost": {
        "rank": 2,
        "rating": "★★★★★",
        "why": "Typically the strongest raw accuracy on small/medium tabular data.",
        "estimator": XGBClassifier(
            n_estimators=300, max_depth=6, learning_rate=0.1,
            random_state=42, eval_metric="logloss"
        )
    },
    "Logistic Regression": {
        "rank": 3,
        "rating": "★★★★",
        "why": "Highly interpretable baseline, fast, good when relationships are linear.",
        "estimator": LogisticRegression(max_iter=1000, random_state=42)
    },
    "LightGBM": {
        "rank": 4,
        "rating": "★★★★",
        "why": "Similar strength to XGBoost; can be less stable on very small datasets.",
        "estimator": LGBMClassifier(
            n_estimators=300, max_depth=6, learning_rate=0.1,
            random_state=42, verbose=-1
        )
    },
    "SVM": {
        "rank": 5,
        "rating": "★★★",
        "why": "Effective on small, clean datasets but slower and less interpretable.",
        "estimator": SVC(probability=True, random_state=42)
    },
}

REGRESSION_MODELS = {
    "Random Forest": {
        "rank": 1,
        "rating": "★★★★★",
        "why": "Robust default, minimal tuning, handles non-linear relationships well.",
        "estimator": RandomForestRegressor(
            n_estimators=300, max_depth=12, min_samples_leaf=2,
            random_state=42, n_jobs=-1
        )
    },
    "XGBoost": {
        "rank": 2,
        "rating": "★★★★★",
        "why": "Highest typical accuracy ceiling for small/medium tabular regression.",
        "estimator": XGBRegressor(
            n_estimators=300, max_depth=6, learning_rate=0.1, random_state=42
        )
    },
    "Ridge Regression": {
        "rank": 3,
        "rating": "★★★★",
        "why": "Interpretable, fast, strong baseline, resistant to overfitting.",
        "estimator": Ridge(alpha=1.0, random_state=42)
    },
    "Gradient Boosting": {
        "rank": 4,
        "rating": "★★★★",
        "why": "Strong accuracy but slower to train than XGBoost on larger sets.",
        "estimator": GradientBoostingRegressor(
            n_estimators=300, max_depth=4, learning_rate=0.1, random_state=42
        )
    },
    "Lasso": {
        "rank": 5,
        "rating": "★★★",
        "why": "Useful when automatic feature selection (sparsity) matters.",
        "estimator": Lasso(alpha=0.01, random_state=42)
    },
}


def get_model_registry(problem_type: str) -> dict:
    return CLASSIFICATION_MODELS if problem_type == "classification" else REGRESSION_MODELS


def train_and_evaluate_all(
    X: pd.DataFrame,
    y,
    problem_type: str,
    numeric_cols: list,
    categorical_cols: list,
    scale_numeric: bool = True,
    test_size: float = 0.2
):
    """
    Trains every model in the registry inside a full preprocessing + model
    pipeline, evaluates on a held-out test split, and returns:
        - leaderboard: DataFrame sorted by primary metric
        - trained_pipelines: dict of {model_name: fitted Pipeline}
    """
    registry = get_model_registry(problem_type)

    stratify = y if problem_type == "classification" else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=stratify
    )

    results = []
    trained_pipelines = {}

    for name, config in registry.items():
        preprocessor = build_preprocessing_pipeline(numeric_cols, categorical_cols, scale_numeric)
        pipeline = Pipeline(steps=[
            ("preprocessor", preprocessor),
            ("model", config["estimator"])
        ])

        start = time.time()
        try:
            pipeline.fit(X_train, y_train)
            train_time = round(time.time() - start, 3)

            y_pred = pipeline.predict(X_test)

            if problem_type == "classification":
                metrics = _classification_metrics(pipeline, X_test, y_test, y_pred)
            else:
                metrics = _regression_metrics(y_test, y_pred)

            metrics.update({
                "Model": name,
                "Rating": config["rating"],
                "Training Time (s)": train_time
            })
            results.append(metrics)
            trained_pipelines[name] = pipeline

        except Exception as e:
            results.append({
                "Model": name,
                "Rating": config["rating"],
                "Training Time (s)": None,
                "Error": str(e)
            })

    leaderboard = pd.DataFrame(results)

    primary_metric = "F1 Score" if problem_type == "classification" else "R2"
    if primary_metric in leaderboard.columns:
        leaderboard = leaderboard.sort_values(primary_metric, ascending=False).reset_index(drop=True)

    return leaderboard, trained_pipelines, (X_test, y_test)


def _classification_metrics(pipeline, X_test, y_test, y_pred) -> dict:
    n_classes = len(np.unique(y_test))
    average = "binary" if n_classes == 2 else "macro"

    metrics = {
        "Accuracy": round(accuracy_score(y_test, y_pred), 4),
        "Precision": round(precision_score(y_test, y_pred, average=average, zero_division=0), 4),
        "Recall": round(recall_score(y_test, y_pred, average=average, zero_division=0), 4),
        "F1 Score": round(f1_score(y_test, y_pred, average=average, zero_division=0), 4),
    }

    try:
        if hasattr(pipeline, "predict_proba"):
            y_proba = pipeline.predict_proba(X_test)
            if n_classes == 2:
                metrics["ROC AUC"] = round(roc_auc_score(y_test, y_proba[:, 1]), 4)
            else:
                metrics["ROC AUC"] = round(roc_auc_score(y_test, y_proba, multi_class="ovr"), 4)
    except Exception:
        metrics["ROC AUC"] = None

    return metrics


def _regression_metrics(y_test, y_pred) -> dict:
    rmse = round(np.sqrt(mean_squared_error(y_test, y_pred)), 4)
    mae = round(mean_absolute_error(y_test, y_pred), 4)
    r2 = round(r2_score(y_test, y_pred), 4)

    try:
        mape = round(mean_absolute_percentage_error(y_test, y_pred) * 100, 2)
    except Exception:
        mape = None

    return {"RMSE": rmse, "MAE": mae, "MAPE (%)": mape, "R2": r2}
