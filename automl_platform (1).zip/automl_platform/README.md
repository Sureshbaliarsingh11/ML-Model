# AutoML Platform (Local Prototype)

A no-code platform for business users: upload a CSV/Excel file, pick what you
want to predict, and the system trains multiple ML models, ranks them on a
leaderboard, and lets you download the best one or run predictions on new data.

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

This opens a browser tab at `http://localhost:8501` — that's your weblink.
Anyone on the same network can reach it via the "Network URL" Streamlit prints
in the terminal (e.g. `http://<your-ip>:8501`).

## Project structure

- `app.py` — Streamlit UI, orchestrates the full workflow
- `preprocessing.py` — missing values, encoding, scaling, outliers, imbalance handling
- `models.py` — algorithm registry (5 classification + 5 regression models) and training/leaderboard logic
- `utils.py` — plain-language explanations, model save/load, predictions on new data
- `saved_models/` — trained models get saved here
- `uploads/` — scratch space for uploaded files

## Supported problem types (v1)

- Classification (e.g., churn yes/no, category prediction)
- Regression (e.g., predicting a number like price or spend)

Clustering, time series, and NLP are not yet included — flagged as v2 scope.

## Notes for small datasets (<10k rows)

The algorithm shortlist intentionally favors tree ensembles (Random Forest,
XGBoost, LightGBM) and linear models (Logistic/Ridge/Lasso) over deep
learning, since neural networks tend to overfit and underperform on this
data scale.

## Tested

Both classification and regression pipelines were tested end-to-end with
synthetic data, including: missing value imputation, class imbalance
detection, the full leaderboard, model save/load, and predictions on new
uploaded data with correct label decoding.
